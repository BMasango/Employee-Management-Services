﻿namespace EMS.Core.Domain.Enums
{
    public enum Gender
    {
        FEMALE,
        MALE
    }

    public enum Province
    {
        GAUTENG,
        NORTHWEST,
        KWAZULUNATAL,
        WESTERNCAPE,
        EASTERNCAPE,
        LIMPOPO,
        MPUMALANGA,
        FREESTATE,
        NORTHERNCAPE
    }
}
